<?php 
	session_start();
    $total= 0;
	include "../conexion.php";

	if(!empty($_POST))
	{  
		$alert='';
		
		if(empty($_POST['cliente']) || empty($_POST['descripcion']) || empty($_POST['cantidad']) ||empty($_POST['precio']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$idcliente = $_POST['cliente'];
			$descripcion  = $_POST['descripcion'];
			$cantidad  = $_POST['cantidad'];
			$precio  = $_POST['precio'];
			$total  = $cantidad*$precio;
			$usuario_id=$_SESSION['idUser'];

				$query_insert = mysqli_query($conection,"INSERT INTO factura(usuario,codcliente,descripcion,cantidad,precio,totalventa)
														VALUES('$usuario_id', '$idcliente', '$descripcion','$cantidad', '$precio', '$total')");
				if($query_insert){
					$alert='<p class="msg_save">Venta registrada correctamente.</p>';
				}else{
					$alert='<p class="msg_error">Error al registrar la venta.</p>';
				}
		}
		
	}


 ?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Registrar venta</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			
			<br>
			<br>
		
			<h1>Registrar venta</h1>

			<form action="" method="post">


		<!---------------------------------Muestra la lista de clientes------>

			<label for="Cliente">Cliente:</label>
     			<?php

				$query_cliente = mysqli_query($conection, "SELECT idcliente, nombre FROM cliente");
				$result_cliente = mysqli_num_rows($query_cliente);
				mysqli_close($conection);
				?>
				<select name="cliente" id="cliente">
				<?php 

				if($result_cliente > 0){

					while($cliente=mysqli_fetch_array($query_cliente)){

				?>

					<option value="<?php echo $cliente['idcliente']; ?>"><?php echo $cliente ['nombre']; ?>
							
					</option>
				<?php

					}
				  }

				?>

				</select>
			<!---------------------------------Fin de la lista de clientes------>
				<label for="detalles">Descripción de la venta:</label>
				
				
				<input type="text" name="descripcion" id="detalles" required="" placeholder="Descripción">
				

				<label for="cantidad">Cantidad de unidades:</label>
				<input type="number" name="cantidad" id="cantidad" required="" placeholder="Cantidad de unidades">

				<label for="precio">Precio por unidad:</label>
				<input type="number" name="precio" id="precio" step="any" required="" placeholder="Precio">

				
				<label for="total">Total a pagar:</label>
				<label>$<?php echo $total; ?></label>

				<input type="submit" value="Aceptar" class="btn_save">

				<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

			</form>

		</div>


	</section>
</body>
</html>