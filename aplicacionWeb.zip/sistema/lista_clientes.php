<?php 
	session_start();
	include "../conexion.php";	

 ?>


<!DOCTYPE html>
<html lang="es">
<head>
	<meta lang="es">
	<meta charset="UTF-8">
	
	<?php include "includes/scripts.php"; ?>
	<title>Clientes</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<br>
		<br>

		<h1>Clientes</h1>
		<a href="registro_cliente.php" class="btn_new">Registrar nuevo cliente</a>

		<table>
			<tr>
				<th>ID</th>
				<th>Número de cliente</th>
				<th>Nombre del cliente</th>
				<th>Teléfono</th>
				<th>Correo</th>
				<th>Dirección</th>
				<th></th>
				
				
			</tr>
		<?php 

			$query = mysqli_query($conection,"SELECT * FROM cliente");

			mysqli_close($conection);

			$result = mysqli_num_rows($query);
			if($result > 0){

				while ($data = mysqli_fetch_array($query)) {
					
			?>
				<tr>
					<td><?php echo $data["idcliente"]; ?></td>
					<td><?php echo $data["numero_cliente"]; ?></td>
					<td><?php echo $data["nombre"]; ?></td>
					<td><?php echo $data["telefono"]; ?></td>
					<td><?php echo $data['email'] ?></td>
					<td><?php echo $data['direccion'] ?></td>
					<td>
						<a class="link_edit" href="editar_cliente.php?id=<?php echo $data["idcliente"]; ?>">Actualizar</a>
						<?php if($_SESSION['rol']==1){?>
						||
						<a class="link_delete" href="eliminar_cliente.php?id=<?php echo $data["idcliente"]; ?>">Eliminar</a>
					    <?php }?>
						
					</td>
				</tr>
			
		<?php 
				}

			}
		 ?>


		</table>
	</section>
</body>
</html>