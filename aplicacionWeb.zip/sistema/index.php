<?php 
	session_start();
 ?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Creatynova</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">

		<br>
		<br>
		<h1>Bienvenido</h1>

		<br>
		<br>

		<img class="creatyinicio" src="img/logoinicio.png"  alt="creatynova" title="Publicidad Creatynova">

	</section>
</body>
</html>