
<?php 
	session_start();
	include "../conexion.php";	

 ?>


<!DOCTYPE html>
<html lang="es">
<head>
	<meta lang="es">
	<meta charset="UTF-8">
	
	<?php include "includes/scripts.php"; ?>
	<title>Ventas</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<br>
		<br>

		<h1>Ventas</h1>
		<a href="registrar_venta.php" class="btn_new">Registrar nueva venta</a>

		<table>
			<tr>
				<th>Número de venta</th>
				<th>Fecha</th>
				<th>Vendedor</th>
				<th>Cliente</th>
				<th>Descripcion del producto</th>
				<th>Cantidad</th>
				<th>Precio</th>
				<th>Precio total</th>
				<th></th>
			</tr>
		<?php 

			$query = mysqli_query($conection, "SELECT f.nofactura, f.fecha, u.usuario, c.nombre, f.descripcion, f.cantidad, f.precio, f.totalventa 
				FROM factura f
				INNER JOIN usuario u, cliente c
				WHERE f.usuario= u.idusuario and f.codcliente= c.idcliente");

			mysqli_close($conection);

			$result = mysqli_num_rows($query);
			if($result > 0){

				while ($data = mysqli_fetch_array($query)) {
					
			?>
				<tr>
					<td><?php echo $data["nofactura"]; ?></td>
					<td><?php echo $data["fecha"]; ?></td>
					<td><?php echo $data["usuario"]; ?></td>
					<td><?php echo $data["nombre"]; ?></td>
					<td><?php echo $data['descripcion'] ?></td>
					<td><?php echo $data['cantidad'] ?></td>
					<td><?php echo $data['precio'] ?></td>
					<td><?php echo $data['totalventa'] ?></td>
					<td>
						
						<a class="link_edit" href="mipdf/imprimir.php?id=<?php echo $data["nofactura"]; ?>">
						    
						Imprimir</a>
						<?php if($_SESSION['rol']==1){?>
						||
						<a class="link_delete" href="eliminar_venta.php?id=<?php echo $data["nofactura"]; ?>">Eliminar</a>
					    <?php }?>
						
					</td>
				</tr>
			
		<?php 
				}

			}
		 ?>


		</table>
	</section>
	
</body>
</html>