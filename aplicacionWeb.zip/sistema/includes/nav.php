		<nav>
			<ul>
				<li><a href="index.php">Inicio</a></li>
			<?php 
				if($_SESSION['rol'] == 1){
			 ?>
				<li class="principal">

					<a href="#">Usuarios</a>
					<ul>
						<li><a href="registro_usuario.php">Nuevo Usuario</a></li>
						<li><a href="lista_usuarios.php">Lista de Usuarios</a></li>
					</ul>
				</li>
			<?php } ?>
				<li class="principal">
					<a href="#">Clientes</a>
					<ul>
						<li><a href="registro_cliente.php">Nuevo Cliente</a></li>
						<li><a href="lista_clientes.php">Lista de Clientes</a></li>
					</ul>
				</li>
				<li class="principal">
					<a href="#">Ventas</a>
					<ul>
						<li><a href="registrar_venta.php">Nueva Venta</a></li>
						<li><a href="listar_ventas.php">Lista de Ventas</a></li>
					</ul>
				</li>
				<li class="principal">
					<a href="#">Ayuda</a>
					<ul>
						<li><a href="introduccion.php">Introducción</a></li>
						<li><a href="informacion_de_api.php">información de la aplicación</a></li>
					</ul>
				</li>
			</ul>
		</nav>