<?php 

	if(empty($_SESSION['active']))
	{
		header('location: ../');
	}
 ?>
	<header>

		<div class="header">
			<img class="creatylogo" src="img/creatynova2.png" alt="Usuario">
			
			<h1></h1>
			<div class="optionsBar">
				<span class="user"><?php echo $_SESSION['user'] ?></span>
				
				<a href="salir.php"><img class="close" src="img/salir.png" alt="Salir del sistema" title="Salir"></a>
			</div>
		</div>
		<?php include "nav.php"; ?>
	</header>