<?php
	session_start();

	include "../../conexion.php";

	//Mostrar Datos
	if(empty($_REQUEST['id']))
	{
		header('Location: listar_ventas.php');
		mysqli_close($conection);
	}
	$nofactura = $_REQUEST['id'];

require('fpdf/fpdf.php'); 

class PDF extends FPDF
{
// Page header 
function Header() 
{ 
// Logo
//$this->Image('../img/creatynova2.png',29,20,60);  
$this->Image('../img/creatynova2.png',10,10,60); 

// Arial bold 15 
$this->SetFont('Arial','B',20); 
// Move to the right 
$this->Cell(180); 
// Title
//$this->Cell(-270,10,'Detalle de la venta',100,100,'C');  
$this->Cell(-270,70,'Detalle de la venta',80,80,'C'); 
// Line break 
//$this->Ln(40);
$this->Ln(-25);

/*

			$this->cell(90,10,utf8_decode('Número de factura'),1,1,'C',0);
			$this->cell(90,10,'Fecha',1,1,'C',0);
			$this->cell(90,10,'Vendedor',1,1,'C',0);
			$this->cell(90,10,'Cliente',1,1,'C',0);
			$this->cell(90,10,utf8_decode('Descripción'),1,1,'C',0);
			$this->cell(90,10,'Cantidad',1,1,'C',0);
			$this->cell(90,10,'Precio por unidad',1,1,'C',0);
			$this->cell(90,10,'Venta total',1,1,'C',0);
			$this->cell(90,10,utf8_decode('Total'),1,1,'C',0);*/
} 
/*
// Page footer 
function Footer() 
{ 
// Position at 1.5 cm from bottom 
$this->SetY(-15); 
// Arial italic 8 
$this->SetFont('Arial','I',8); 
// Page number 
$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C'); 
}*/ 
}

	$sql= mysqli_query($conection, "SELECT f.nofactura, f.fecha, u.usuario, c.nombre, f.descripcion, f.cantidad, f.precio, f.totalventa 
				FROM factura f
				INNER JOIN usuario u, cliente c
				WHERE f.usuario= u.idusuario and f.codcliente= c.idcliente and f.nofactura=$nofactura");
	mysqli_close($conection);

	$result = mysqli_num_rows($sql);

$pdf = new PDF(); 
$pdf->AddPage(); 
$pdf->SetFont('Arial','',16);
$pdf->SetFillColor(209, 242, 235); // establece el color del fondo de la celda (en este caso es AZUL
//$pdf->Cell(40,10,utf8_decode('¡hola mundo!')); 
	if($result == 0){
		header('Location: listar_ventas.php');
	}else{
		
		while ($data = mysqli_fetch_array($sql)) {

/*
			$factura= $data['nofactura'];
			$fecha = $data['fecha'];
			$vendedor= $data['usuario'];
			$cliente= $data['nombre'];
			$descripcion= $data['descripcion'];
			$cantidad= $data['cantidad'];
			$precio= $data['precio'];
			$total= $data['totalventa'];
*/		
			$pdf->SetFont('Arial','B',15); 
			//$pdf->SetFillColor(232,232,232);
			$pdf->cell(90,10,utf8_decode('Número de factura'),1,0,'C',True);
			$pdf->SetFont('Arial','',15);
			$pdf->cell(90,10,$data['nofactura'],1,1,'C',True);
			$pdf->SetFont('Arial','B',15); 
			$pdf->cell(90,10,'Fecha',1,0,'C',0);
			$pdf->SetFont('Arial','',15);
			$pdf->cell(90,10,$data['fecha'],1,1,'C',0);
			$pdf->SetFont('Arial','B',15);
			$pdf->cell(90,10,'Vendedor',1,0,'C',True);
			$pdf->SetFont('Arial','',15);
			$pdf->cell(90,10,utf8_decode($data['usuario']),1,1,'C',True);
			$pdf->SetFont('Arial','B',15);
			$pdf->cell(90,10,'Cliente',1,0,'C',0);
			$pdf->SetFont('Arial','',15);
			$pdf->cell(90,10,utf8_decode($data['nombre']),1,1,'C',0);
			$pdf->SetFont('Arial','B',15);
			$pdf->cell(90,10,utf8_decode('Descripción'),0,0,'C',True);
			$pdf->SetFont('Arial','',15);
			$pdf->MultiCell(90,7,utf8_decode($data['descripcion']),1,'L',True);
			$pdf->SetFont('Arial','B',15);
			$pdf->cell(90,10,'Cantidad',1,0,'C',0);
			$pdf->SetFont('Arial','',15);
			$pdf->cell(90,10,$data['cantidad'],1,1,'C',0);
			$pdf->SetFont('Arial','B',15);
			$pdf->cell(90,10,'Precio por unidad',1,0,'C',True);
			$pdf->SetFont('Arial','',15);
			$pdf->cell(90,10,$data['precio'],1,1,'C',True);
			$pdf->SetFont('Arial','B',15);
			$pdf->cell(90,10,'Venta total',1,0,'C',0);
			$pdf->SetFont('Arial','',20);
			$pdf->cell(90,10,$data['totalventa'],1,1,'C',0);

		}
	}

$pdf->Output(); 
?>