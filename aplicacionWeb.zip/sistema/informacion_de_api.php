<?php 
	session_start();
 ?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Versión</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">

<br>
<br>
<br>
<h1 class="titulo" >Sistema de gestión de información. Publicidad Creatynova</h1>
<br>
<br>
<p class="creatytext">Versión 1.0.0</p>
<br>

	<img class="creatyimagen" src="img/creatynfo.png" alt="creatynova">

	</section>
</body>
</html>



