<?php 
	session_start();

	include "../conexion.php";

	if(!empty($_POST))
	{
		$alert='';
		if(empty($_POST['nombre']) || empty($_POST['telefono']) || empty($_POST['correo']) || empty($_POST['direccion']))
		{
			$alert='<p class="msg_error">Todos los campos son obligatorios.</p>';
		}else{

			$numero = $_POST['numero'];
			$nombre = $_POST['nombre'];
			$telefono  = $_POST['telefono'];
			$correo  = $_POST['correo'];
			$direccion    = $_POST['direccion'];
			$usuario_id=$_SESSION['idUser'];

			$result=0;

			if(is_numeric($numero))
			{
				$query = mysqli_query($conection,"SELECT * FROM cliente WHERE numero_cliente = '$numero' ");
				$result=mysqli_fetch_array($query);
			}
			if($result>0){
				$alert='<p class="msg_error">El número del cliente ya existe</p>';
			}else{
				$query_insert = mysqli_query($conection,"INSERT INTO cliente(numero_cliente,nombre,telefono,email,direccion,usuario_id)
																	VALUES('$numero','$nombre','$telefono','$correo','$direccion','$usuario_id')");
				if($query_insert){
					$alert='<p class="msg_save">Cliente guardado correctamente.</p>';
				}else{
					$alert='<p class="msg_error">Error al crear cliente.</p>';

				}

			}

		}
		mysqli_close($conection);

	}


 ?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Registrar cliente</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div class="form_register">
			
			<br>
			<br>
		
			<h1>Registrar cliente</h1>

			<form action="" method="post">
				<label for="numero">Número de cliente:</label>
				<input type="tex" name="numero" id="numero" pattern="[0-9]+" required="" placeholder="Número de cliente" >
				
				<label for="nombre">Nombre:</label>
				<input type="text" name="nombre" id="nombre" minlength="4" pattern="[a-z A-Z á é í ó ú ñ Á É Í Ó Ú Ñ]+" required=""placeholder="Nombre">
				
				<label for="telefono">Teléfono:</label>
				<input type="tex" name="telefono" id="telefono" maxlength="12" pattern="[0-9]+" required=""placeholder="teléfono">
				
				<label for="correo">Correo:</label>
				<input type="email" name="correo" id="correo" required="" placeholder="Correo">
				
				<label for="text">Dirección:</label>
				<input type="text" name="direccion" id="direccion" minlength="10" required="" placeholder="Dirección">

				<input type="submit" value="Aceptar" class="btn_save">

				<div class="alert"><?php echo isset($alert) ? $alert : ''; ?></div>

			</form>


		</div>


	</section>
</body>
</html>