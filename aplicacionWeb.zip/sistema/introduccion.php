<?php 
	session_start();
 ?>

<!DOCTYPE html>
<html lang="es">
<head>	

    <meta lang="es">
	<meta charset="UTF-8">
	
	<?php include "includes/scripts.php"; ?>
	<title>Introducción</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">


		<br>
		<br>
		<br>
		<h1>Introducción</h1>
		<br>
		<br>
		<p>
			Esta aplicación le permitir&aacute  gestionar toda la información de su empresa Publicidad Creatynova. <br>
			La aplicación contar&aacute con tres tipos de usuario: <br>
			1. Directora de la empresa<br>
			2. Administrador.<br>
			3. Vendedor.<br>

			Para poder acceder al sistema, deber&aacute introducir su nombre de usuario y su clave de acceso 	
		</p>
		<br>
		<img class="imagencreaty" src="img/inisesion.png" alt="creatynova">
		
				<br>

		<p>
			El usuario con rol de administrador podrá registrar usuarios en el sistema, así como también registrar clientes y ventas.
			<img class="imagencreaty" src="img/registrousuario.png">
		</p>

		<br>

		<p>
			El usuario con rol de vendedor únicamente podrá registrar clientes  y registrar ventas.
			<br>
			<img class="imagencreaty" src="img/registroventa.png">
		</p>

		<br>

		<p>
			Preguntas frecuentes<br>
			¿Qué pasa  si olvido mi contraseña?<br>
			Deberá ponerse en contacto con el administrador del sistema para que nuevamente le proporcione su contraseña de acceso. 
			<br><br>


		</p>

	</section>
</body>
</html>