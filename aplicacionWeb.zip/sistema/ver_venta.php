<?php 
	
	session_start();

	include "../conexion.php";

	//Mostrar Datos
	if(empty($_REQUEST['id']))
	{
		header('Location: listar_ventas.php');
		mysqli_close($conection);
	}
	$nofactura = $_REQUEST['id'];


	$sql= mysqli_query($conection, "SELECT f.nofactura, f.fecha, u.usuario, c.nombre, f.descripcion, f.cantidad, f.precio, f.totalventa 
				FROM factura f
				INNER JOIN usuario u, cliente c
				WHERE f.usuario= u.idusuario and f.codcliente= c.idcliente and f.nofactura=$nofactura");
	mysqli_close($conection);

	$result = mysqli_num_rows($sql);

	if($result == 0){
		header('Location: listar_ventas.php');
	}else{
		
		while ($data = mysqli_fetch_array($sql)) {

			$factura= $data['nofactura'];
			$fecha = $data['fecha'];
			$vendedor= $data['usuario'];
			$cliente= $data['nombre'];
			$descripcion= $data['descripcion'];
			$cantidad= $data['cantidad'];
			$precio= $data['precio'];
			$total= $data['totalventa'];
		}
	}

	?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<?php include "includes/scripts.php"; ?>
	<title>Venta</title>
</head>
<body>
	<?php include "includes/header.php"; ?>
	<section id="container">
		
		<div>

	<br><br>
			<h1>Venta:</h1>
			<br>
			<br>

			<table class="ver">
				<tr><td><b>Número de venta:</b></td><td><?php echo $factura?></td></tr>
				<tr><td><b>Fecha:</b></td><td><?php echo $fecha?></td></tr>
				<tr><td><b>Vendedor:</b></td><td><?php echo $vendedor?></td></tr>
				<tr><td><b>Cliente:</b></td><td><?php echo $cliente?></td></tr>
				<tr><td><b>Descripción de la venta:</b></td><td><?php echo $descripcion?></td></tr>
				<tr><td><b>Cantidad de unidades:</b></td><td><?php echo $cantidad?></td></tr>
				<tr><td><b>Precio por unidad:</b></td><td><?php echo "$ ";?><?php echo $precio?></td></tr>
				<tr><td><b>Total a pagar:</b></td><td><?php echo "$ ";?><?php echo $total?></td></tr>

			</table>
			
			
				


		</div>


	</section>
	
</body>
</html>

