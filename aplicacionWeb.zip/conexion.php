<?php 
	
	$host = 'localhost';
	$user = 'mariohue_Mario';
	$password = 'L%g[V!hBg,@1';
	$db = 'mariohue_db';

	$conection = @mysqli_connect($host,$user,$password,$db);

	if(!$conection){
		echo "Error en la conexión";
	}

?>